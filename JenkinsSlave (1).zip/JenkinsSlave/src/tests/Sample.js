var cred = require('../configurations/credentials');
var obj = require('../configurations/object');

describe('jenkins homepage', function () {
    it('should have the correct title', function () {
        browser.driver.get('http://localhost:8080/'); //Assuming jenkins is running on localhost, port 8080
        var title = browser.driver.getTitle();
        expect(title).toEqual('Dashboard [Jenkins]');
    });
/*
    it('should have the correct title', function () {
        browser.driver.get('http://localhost:8080/'); //Assuming jenkins is running on localhost, port 8080
        var title = browser.driver.getTitle();
        expect(title).toEqual('Dashboard [Jenkinns]');
    });
*/

});

