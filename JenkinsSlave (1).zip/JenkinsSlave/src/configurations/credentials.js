//This file contains test data - credentials,ssotoken, text and urls

module.exports = {
    url: 'http://www.angularjs.org',
    name: 'Julie',

};
