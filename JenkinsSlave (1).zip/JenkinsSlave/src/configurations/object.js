//This file contains element locators and their values
//help doc: http://angular.github.io/protractor/#/api

module.exports = {
    name: 'yourName',

};
