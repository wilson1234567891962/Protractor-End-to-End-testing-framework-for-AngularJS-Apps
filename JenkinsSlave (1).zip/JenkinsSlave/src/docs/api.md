Protractor API
==============

The API documentation was moved to: http://angular.github.io/protractor/#/api
