

exports.config = {


	//directConnect: true,
	seleniumAddress: 'http://localhost:4723/wd/hub',



	// Capabilities to be passed to the webdriver instance.
	capabilities: {
		browserName: 'chrome',
		platformName: 'android',
		deviceName:''


	},


	framework: 'jasmine2',



	specs: ['./rough/CustomerLogin.js'],

	/*suites: {

			smoke: ['./smoke/!*.spec.js'],
			regression: ['./regression/!*.spec.js'],
			functional: ['./functional/!*.spec.js'],
			all: ['./!*!/!*.spec.js'],
			selected: ['./functional/addcustomer.spec.js','./regression/openaccount.spec.js'],


	},*/



	// Options to be passed to Jasmine.
	jasmineNodeOpts: {
		defaultTimeoutInterval: 30000
	}









}