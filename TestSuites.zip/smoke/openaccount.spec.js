
describe("Test Automation of a banking app",function(){

    it("validate customer login test",function(){

        browser.get("http://www.way2automation.com/angularjs-protractor/banking/#/login");
        element(by.buttonText("Customer Login")).click();
        console.log("Smoke: Executing Open account test");

    });



});